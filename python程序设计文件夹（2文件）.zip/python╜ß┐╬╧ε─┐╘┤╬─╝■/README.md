# Address
https://github.com/Mooncodesource/Defending-the-Fortress

# Environment
```
OS: Windows10
Python: Python3.10(have installed necessary dependencies)
```

# Usage
```
Step1:
pip install uninstalled modules
Step2:
run "python main.py"
```
