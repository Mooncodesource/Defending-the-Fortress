import math
import pygame
import numpy as np
from scipy.spatial import cKDTree
from sprites import Arrow

'''炮塔类'''


class Turret(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        # 类型
        self.type = "turret"
        # 目标
        self.target = None
        self.image = pygame.image.load("imgs/tower.png")
        self.rect = self.image.get_rect()
        # 当前的位置
        self.coord = 0, 0
        self.position = 0, 0
        self.radius = 200  # 攻击范围
        self.rect.left, self.rect.top = self.position
        # 价格
        self.price = 500
        # 射箭的冷却时间
        self.coolTime = 45
        # 是否在冷却期
        self.is_cooling = False

        '''
        self.enemy_positions = []
        self.enemy_indices = []
        self.enemy_tree = None
        '''
    ''''
    # 优先队列算法
    def update_enemy_tree(self, enemies):
        self.enemy_positions = [enemy.position for enemy in enemies]
        self.enemy_indices = list(range(len(enemies)))
        self.enemy_tree = cKDTree(list(zip(self.enemy_positions, self.enemy_indices)))

    def find_target(self, enemies):
        _, enemy_indices = self.enemy_tree.query_ball_point(self.position, self.radius)
        if not enemy_indices:
            return None
        enemy_distances = [(i, np.linalg.norm(enemies[i].position - self.position)) for i in enemy_indices]
        enemy_distances.sort(key=lambda x: x[1])
        return enemy_indices[enemy_distances[0][0]]

    '''
    # 判断敌人是否进入炮塔范围
    def update(self, enemies):
        # 定义一个优先队列，用于存储在攻击范围内的敌人
        # 检测与所有敌人的距离
        for enemy in enemies:
            distance = math.sqrt((self.position[0] - enemy.position[0]) ** 2
                                 + (self.position[1] - enemy.position[1]) ** 2)
            if distance <= self.radius:
                # 如果敌人在攻击范围内，加入到攻击目标
                self.target = enemy
                return enemy
            else:
                continue
        return False

    '''射击'''

    def shot(self, position, angle):
        arrow = None
        if not self.is_cooling: # 不在冷却
            # 生成炮弹并更新角度
            arrow = Arrow.Arrow()
            arrow.update(position, angle)
            self.is_cooling = True
        if self.is_cooling: # 在冷却进入cd
            self.coolTime -= 1
            if self.coolTime == 0:
                self.coolTime = 45
                self.is_cooling = False
        return arrow


