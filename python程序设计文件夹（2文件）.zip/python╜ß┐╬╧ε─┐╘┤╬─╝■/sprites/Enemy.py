import pygame
'''敌方类'''

class Enemy(pygame.sprite.Sprite):
    def __init__(self, enemy_type):
        pygame.sprite.Sprite.__init__(self)
        self.enemy_type = enemy_type
        self.image = pygame.image.load('imgs/enemy.png')
        self.rect = self.image.get_rect()
        # 走过的路(避免重复走，保证去攻击城堡)
        self.reached_path = []
        # 在道路某个单元中移动的距离, 当cell_move_dis大于单元长度时移动到下一个到了单元并置0该变量
        self.move_dis = 0
        # 当前所在的位置
        coords = [(3, 2), (37, 3), (2, 21), (36, 22)]
        positions = [(60, 40), (740, 60), (40, 420), (720, 440)]

        # 类型
        self.type = "enemy"
        if enemy_type == 0:
            self.coord = coords[0]
            self.position = positions[0]
            self.rect.left, self.rect.top = self.position
            # 最大生命值
            self.max_life_value = 35
            # 当前生命值
            self.life_value = 35
            # 速度
            self.speed = 2
            # 击杀奖励
            self.reward = 35
            self.score = 35
            # 对大本营造成的伤害
            self.damage = 2
        elif enemy_type == 1:
            self.coord = coords[1]
            self.position = positions[1]
            self.rect.left, self.rect.top = self.position
            self.max_life_value = 50
            self.life_value = 50
            self.speed = 1
            self.reward = 50
            self.score = 50
            self.damage = 4
        elif enemy_type == 2:
            self.coord = coords[2]
            self.position = positions[2]
            self.rect.left, self.rect.top = self.position
            self.max_life_value = 70
            self.life_value = 70
            self.speed = 0.5
            self.reward = 70
            self.score = 70
            self.damage = 6
        elif enemy_type == 3:
            self.coord = coords[3]
            self.position = positions[3]
            self.rect.left, self.rect.top = self.position
            self.max_life_value = 100
            self.life_value = 100
            self.speed = 0.2
            self.reward = 100
            self.score = 100
            self.damage = 8

    '''不停地移动'''

    def move(self, cell_Len):
        is_next_cell = False
        self.move_dis += self.speed
        # 经过时间累加speed，如果大于一个方块的size判定敌人位置往下一个方块更新，否则False
        if self.move_dis > cell_Len:
            self.move_dis = 0
            is_next_cell = True
        return is_next_cell
