import pygame

'''炮弹类'''

class Arrow(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        # 精灵类型
        self.type = "arrow"
        # 炮弹图片
        self.image = pygame.image.load("imgs/bullet.png")
        # 炮弹位置
        self.position = 0, 0
        # 矩形对象
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = self.position
        # 发射角度
        self.angle = 0
        # 前进速度
        self.speed = 10
        # 攻击伤害
        self.attack_power = 5

    '''更新炮弹的位置'''

    def update(self, position, angle=None):
        self.angle = angle
        self.position = position


    '''朝angle方向移动'''

    def move(self):
        self.position = self.position[0] + self.speed * self.angle[0], self.position[1] + self.speed * self.angle[1]
        self.rect.left, self.rect.top = self.position






