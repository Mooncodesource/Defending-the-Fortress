import sys
import math
import random
import pygame
import time
from sprites import Enemy
from sprites import Turret
from collections import namedtuple

'''
class Enemy(): # 敌人类
    def __init__(self):
class Turret(): # 炮塔类
    def __init__(self):
class Arrow(): # 炮弹类
    def __init__(self):
'''

WIDTH = 800  # 窗口长度
HEIGHT = 600  # 窗口宽度
red = (255, 0, 0)  # 红色
green = (0, 255, 0)  # 绿色
black = (0, 0, 0)  # 黑色
white = (255, 255, 255)  # 白色
button_color1 = (0, 200, 0)  # 按钮颜色1
button_color2 = (0, 100, 0)  # 按钮颜色2


class QuadTree():  # 四叉树碰撞检测算法
    def __init__(self, x, y, width, height, level=0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.level = level
        self.children = []
        self.objects = []

    def split(self):  # 递归分割窗口至四个象限
        sub_width, sub_height = self.width // 2, self.height // 2
        x, y = self.x, self.y
        # 划分四叉树
        self.children.append(QuadTree(x, y, sub_width, sub_height, self.level + 1))
        self.children.append(QuadTree(x + sub_width, y, sub_width, sub_height, self.level + 1))
        self.children.append(QuadTree(x, y + sub_height, sub_width, sub_height, self.level + 1))
        self.children.append(QuadTree(x + sub_width, y + sub_height, sub_width, sub_height, self.level + 1))

    def insert(self, game_obj):  # 插入游戏元素
        if len(self.children) > 0:
            index = self.get_quadrant(game_obj)
            if index != -1:
                self.children[index].insert(game_obj)
                return

        self.objects.append(game_obj)
        if len(self.objects) > 4 and self.level < 10:  # 超过 4 个元素 且 母节点不超过 10 层
            if len(self.children) == 0:
                self.split()
            i = 0
            while i < len(self.objects):
                index = self.get_quadrant(self.objects[i])
                if index != -1:
                    self.children[index].insert(self.objects.pop(i))
                else:
                    i += 1

    def retrieve(self, game_obj):
        objects = self.objects
        if len(self.children) > 0:
            index = self.get_quadrant(game_obj)
            if index != -1:
                objects += self.children[index].retrieve(game_obj)

        return objects

    def get_quadrant(self, game_obj):  # 返回当前游戏元素所处的象限值
        left = self.x <= game_obj.position[0] <= self.x + self.width
        top = self.y <= game_obj.position[1] <= self.y + self.height
        if not left or not top:
            return -1

        l_x = self.x + (self.width // 2)
        l_y = self.y + (self.height // 2)

        right = game_obj.position[0] <= l_x
        bottom = game_obj.position[1] <= l_y

        if right and bottom:
            return 0
        elif not right and bottom:
            return 1
        elif right and not bottom:
            return 2
        elif not right and not bottom:
            return 3


class GAMING():
    def __init__(self, WIDTH=None, HEIGHT=None):
        # 窗口大小
        self.WIDTH = WIDTH
        self.HEIGHT = HEIGHT
        # 游戏地图大小
        map_w = WIDTH  # 长
        map_h = 500  # 宽
        # 界面布置
        self.map_surface = pygame.Surface((map_w, map_h))  # 画布（800，500）
        self.map_rect = pygame.Rect(0, 0, map_w, map_h)  # 地图矩形
        self.info_rect = pygame.Rect(0, 500, 800, 100)  # 显示框矩形

        # 信息显示框字体
        self.info_font = pygame.font.Font(None, 23)
        self.button_font = pygame.font.Font(None, 29)
        # 按钮类: 位置、文本、点击触发的事件
        Button = namedtuple('Button', ['rect', 'text', 'onClick'])
        # 玩家操作用的按钮
        self.buttons = \
            [
                Button(pygame.Rect((self.WIDTH // 2 + 170), 510, 80, 80), 'Building', self.takeT),
                Button(pygame.Rect((self.WIDTH // 2 + 300), 510, 80, 80), 'Selling', self.takeX)
            ]

        # 四叉树碰撞检测算法实例化
        self.quad_tree = QuadTree(0, 0, self.WIDTH, self.HEIGHT)

        self.tomb = pygame.image.load("imgs/tomb.png")  # tomb
        self.rock = pygame.image.load("imgs/rock.png")  # 岩石(敌人道路)
        self.dirt = pygame.image.load("imgs/dirt.png")  # 污垢
        self.lava = pygame.image.load("imgs/lava.png")  # 岩浆
        self.nexus = pygame.image.load("imgs/nexus.png")  # 城堡
        self.rect = pygame.image.load("imgs/rect.png")  # 城墙

        # 地图元素字典(数字对应.map文件中的数字)
        self.map_elements = {
            0: self.tomb,
            1: self.rock,
            2: self.dirt,
            3: self.lava,
            4: self.nexus,
            5: self.rect

        }

        # 记录游戏开始时间
        self.start_time = time.time()
        # 游戏初始金币
        self.money = 3000
        # 游戏得分
        self.score = 0
        # 城堡生命值
        self.health = 50
        self.max_health = 50

        # 获取地图元素的大小，请保证素材库里组成地图的元素图大小一致
        self.elementSize = int(self.tomb.get_rect().width)
        # 可以放炮塔的地方
        self.placeable = {0: self.tomb, 3: self.lava}
        # 敌人前进道路
        self.path_list = []
        # 当前的地图，将地图导入到这里面
        self.currentMap = dict()
        # 当前鼠标携带的图标(即选中道具) -> [道具名, 道具]
        self.mouseCarried = []

        # 所建炮塔精灵组
        self.builtTurretGroup = pygame.sprite.Group()
        # 所有敌人精灵组
        self.EnemiesGroup = pygame.sprite.Group()
        # 所有的炮弹精灵组
        self.arrowsGroup = pygame.sprite.Group()
        # 所有游戏对象列表
        self.game_objects = []

        '''开始游戏'''

    def start(self, screen):
        clock = pygame.time.Clock()  # 声明一个clock

        # 自定义事件，每45s生成一波敌人
        GenEnemiesEvent = pygame.constants.USEREVENT + 0
        pygame.time.set_timer(GenEnemiesEvent, 30000)
        # 自定义事件，每1.5秒出一个敌人
        GenEnemyEvent = pygame.constants.USEREVENT + 1
        pygame.time.set_timer(GenEnemyEvent, 1000)
        genEnemyFlag = False

        # 敌人等级和数量
        enemyRange = 4
        numEnemy = 0

        '''开始循环'''
        while True:
            # 城堡生命值降为0，游戏结束
            if self.health <= 0:
                return

            # 遍历事件
            for event in pygame.event.get():
                # 退出游戏
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                # 检测鼠标操作
                if event.type == pygame.MOUSEBUTTONUP:
                    # 检测到鼠标左键操作
                    if event.button == 1:
                        # 判断鼠标所点区域
                        if self.map_rect.collidepoint(event.pos):  # 如果是在map区域，则进行炮塔建造
                            # 如果鼠标携带道具，判断道具类型
                            if self.mouseCarried:
                                if self.mouseCarried[0] == 'turret':  # 建筑到鼠标的位置
                                    self.build_Turret(event.pos)
                                elif self.mouseCarried[0] == 'XXX':  # 鼠标点击位置进行售卖
                                    self.sell_Turret(event.pos)

                        elif self.info_rect.collidepoint(event.pos):  # 如果是信息框区域，则进行选取
                            for button in self.buttons:
                                # 判断在工具栏的哪个区域，是否在按钮区域
                                if button.rect.collidepoint(event.pos):  # 在按钮区域响应，其他区域不响应
                                    # 判断是哪个按钮：根据按钮的text判断
                                    if button.text == 'Building':
                                        button.onClick()  # 响应操作，使鼠标携带相应道具
                                    elif button.text == 'Selling':
                                        button.onClick()  # 响应操作，使鼠标携带相应道具
                                    break
                                    # 显然只能有一个按钮被点击

                # 先生成敌人群事件constants.USEREVENT+0
                if event.type == GenEnemiesEvent:
                    numEnemy = 10  # 生成一波敌人，敌人数量为10
                # 再生成单个敌人事件constants.USEREVENT+1
                if event.type == GenEnemyEvent:
                    genEnemyFlag = True  # 生成敌人标志
                # 30s一波敌人，一波敌人10个，每秒生成一个敌人

            if genEnemyFlag and numEnemy:  # 生成敌人标志为True且敌人数量不为0，应该进行生成敌人
                genEnemyFlag = False  # 每秒都要生成，需要更新标志
                # 生成一个敌人就要numEnemy-1
                numEnemy -= 1
                # 把生成的敌人加入到精灵组中
                enemy = Enemy.Enemy(random.choice(range(enemyRange)))
                self.EnemiesGroup.add(enemy)

            # 生成敌人之后炮塔进行攻击,炮塔怎么来？事件循环检索鼠标操作
            for turret in self.builtTurretGroup:  # 遍历每个炮塔进行攻击操作
                # 炮塔/炮弹初始位置
                position = turret.position
                # turret.update_enemy_tree(self.EnemiesGroup)
                # 获取最近敌人的索引和位置
                # nearest_index, nearest_pos = turret.find_target(self.EnemiesGroup)
                # if nearest_index is not None:
                # 使用炮塔攻击最近的敌人
                # 计算角度
                # theta = math.atan2(self.position[1] - nearest_pos.position[1],
                #                   self.position[0] - nearest_pos.position[0])
                # 将弧度转化为角度
                # angle = math.degrees(theta)
                if turret.target and turret.target.life_value > 0:  # 炮塔含有目标并且目标存活
                    # 添加炮弹
                    # 计算角度
                    # 炮塔相对于敌人的角度
                    # 若在第一象限
                    # 计算炮弹的路径和射击方向
                    dx = turret.target.position[0] - position[0]  # 目标和炮塔水平矢量距离
                    dy = turret.target.position[1] - position[1]  # 目标和炮塔垂直矢量距离
                    # 计算二者实际距离，便于判断敌人是否进入攻击范围
                    distance = math.dist(turret.target.position, position)
                    # 从而计算二者之间的角度，矢量，便于炮弹方向攻击
                    angle = (dx / distance, dy / distance)

                    # 生成一个炮弹，以angle为方向，position为初始位置
                    arrow = turret.shot(position, angle)  # 炮塔根据初始位置和方向返回一个arrow对象
                    # 因为炮塔含有攻击间隔，所以判定该炮塔是否生成了一个arrow对象
                    if arrow:  # 生成即添加到精灵组，反之则过时间间隔再生成
                        self.arrowsGroup.add(arrow)  # 添加一个有方向的炮弹
                # 如果目标死了或者攻击到了城堡导致该对象被删除，则选择下一个敌人，更换目标
                else:
                    # 炮塔更新目标操作，遍历敌人精灵组进行更换目标，判断哪个敌人在攻击范围内
                    turret.target = turret.update(self.EnemiesGroup)

            # 将敌人和箭添加到self.game_objects列表中
            self.game_objects += self.EnemiesGroup.sprites()
            self.game_objects += self.arrowsGroup.sprites()
            '''
            # 四叉树法碰撞检测
            for obj in self.game_objects:
                if obj.type == 'arrow' or obj.type == 'enemy':
                    self.quad_tree.insert(obj)

            # 查询QuadTree中近邻的炮弹、敌人列表，炮弹和敌人之间的碰撞可以在这里完成
            for enemy in self.EnemiesGroup:
                objects = self.quad_tree.retrieve(enemy)
                for obj in objects:
                    if obj.type == 'arrow':
                        if pygame.sprite.collide_rect(obj, enemy):  # 处理炮弹与敌人的碰撞事件
                            enemy.health -= obj.damage
                            # 移除炮弹
                            self.arrowsGroup.remove(arrow)
                            del arrow
                            break
                        else:
                            continue
            '''
            # 遍历每个炮弹进行移动以及碰撞检测操作
            for arrow in self.arrowsGroup:
                # 炮塔不断的往指定的方向前进
                arrow.move()
                # 取炮弹道具元素的四个角，左上，左下，右上，右下。
                points = [(arrow.rect.left, arrow.rect.top), (arrow.rect.left, arrow.rect.bottom),
                          (arrow.rect.right, arrow.rect.top), (arrow.rect.right, arrow.rect.bottom)]
                # 如果炮弹四个角的坐标值都不在地图里，则移除这个炮弹
                if (not self.map_rect.collidepoint(points[0])) and \
                        (not self.map_rect.collidepoint(points[1])) and \
                        (not self.map_rect.collidepoint(points[2])) and \
                        (not self.map_rect.collidepoint(points[3])):
                    self.arrowsGroup.remove(arrow)
                    del arrow
                    continue

                # 再逐一遍历敌人，如果和炮弹碰撞，则扣血，并移除炮弹
                for enemy in self.EnemiesGroup:
                    if pygame.sprite.collide_rect(arrow, enemy):  # 检测炮弹敌人是否碰撞
                        enemy.life_value -= arrow.attack_power
                        self.arrowsGroup.remove(arrow)
                        del arrow
                        break

            # 更新屏幕
            self.draw(screen)
            clock.tick(30)  # 控制游戏帧率

    def draw(self, screen):
        self.draw_Map(screen)  # 画地图
        self.draw_InfoBar(screen)  # 画底部信息显示框
        self.draw_MouseCarried(screen)  # 画鼠标所携带的道具
        self.draw_BuiltTurret(screen)  # 画建造好的炮塔
        self.draw_Enemies(screen)  # 画敌人
        self.draw_Arrows(screen)  # 画发射的炮弹
        pygame.display.flip()  # 刷新屏幕

    '''画地图'''

    def draw_Map(self, screen):
        map_file = open('1.map', 'r')  # 打开文件
        idx_j = -1
        for line in map_file.readlines():
            # 去掉首尾空格符
            line = line.strip()
            if not line:
                continue
            idx_j += 1
            idx_i = -1
            for col in line:  # 按顺序读取每一行的数字
                try:
                    # 每个数字对应一种图片类型，窗口画出之
                    element_type = int(col)
                    element_img = self.map_elements.get(element_type)
                    element_rect = element_img.get_rect()
                    idx_i += 1
                    # 图片矩形的大小，坐标（x,y）
                    element_rect.left, element_rect.top = self.elementSize * idx_i, self.elementSize * idx_j
                    # 窗口地图区域加载图片
                    self.map_surface.blit(element_img, element_rect)  # 加载需要元素图片和图片坐标，坐标在rect中
                    # 把每一个像素图片对应的坐标值记录到这个字典中，键为坐标值，值为图片的种类
                    self.currentMap[idx_i, idx_j] = element_type
                    # 把道路记下来，原始坐标
                    if element_type == 1:
                        self.path_list.append((idx_i, idx_j))
                except:
                    continue
        # 放洞穴和大本营
        self.map_surface.blit(self.nexus, (380, 240))
        # 大本营的血条
        nexus_width = self.nexus.get_rect().width
        # 绿色血条
        greenLen = max(0, self.health / self.max_health) * nexus_width
        if greenLen > 0:
            pygame.draw.line(self.map_surface, green, (380, 240), (380 + greenLen, 240), 3)  # 画布，颜色，始末位置，粗细
        if greenLen < nexus_width:  # 从绿色血条最末尾开始画出红色血条到血条线最末尾
            pygame.draw.line(self.map_surface, red, (380 + greenLen, 240), (380 + nexus_width, 240), 3)
        screen.blit(self.map_surface, (0, 0))  # 在 map_surface上画像素，在窗口画 map_surface
        map_file.close()  # 关闭文件

    '''画底部显示框'''

    def draw_InfoBar(self, screen):
        # 信息显示框黑色
        pygame.draw.rect(screen, black, self.info_rect)

        # 计算游戏运行的时间
        elapsed_time = time.time() - self.start_time
        # 将时间转换为字符串
        time_str = time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
        # 创建时间文本对象
        time_text = self.info_font.render(time_str, True, white)

        # 在窗口中显示时间文本
        screen.blit(time_text, (200, 510))
        # 导入文本并显示
        leftTitle = self.info_font.render('Gaming info:', True, white)
        moneyInfo = self.info_font.render('Money: ' + str(self.money), True, white)
        healthInfo = self.info_font.render('Health: ' + str(self.health), True, white)
        scoreInfo = self.info_font.render('Score: ' + str(self.score), True, white)
        enemyInfo_1 = self.info_font.render('The level of the monster varies depending on the four corners',
                                            True, white)
        enemyInfo_2 = self.info_font.render('Difficulty up levels are: ',
                                            True, white)
        enemyInfo_3 = self.info_font.render('top_left, top_right, bottom_left, bottom_right',
                                            True, white)
        screen.blit(leftTitle, (5, 505))
        screen.blit(moneyInfo, (5, 530))
        screen.blit(healthInfo, (5, 555))
        screen.blit(scoreInfo, (5, 580))
        screen.blit(enemyInfo_1, (109, 530))
        screen.blit(enemyInfo_2, (110, 555))
        screen.blit(enemyInfo_3, (200, 580))

        # 画按钮，鼠标点击与否，按钮颜色更改
        for button in self.buttons:
            # buttons 逐个显示
            mouse_pos = pygame.mouse.get_pos()
            if button.rect.collidepoint(mouse_pos):
                button_color = button_color1
            else:
                button_color = button_color2
            pygame.draw.rect(screen, button_color, button.rect)
            # 按钮信息
            buttonText = self.button_font.render(button.text, True, red)
            # 信息位置按钮中心
            buttonText_rect = buttonText.get_rect()
            buttonText_rect.center = (button.rect.centerx, button.rect.centery)
            screen.blit(buttonText, buttonText_rect)

    '''画鼠标携带物'''

    def draw_MouseCarried(self, screen):
        if self.mouseCarried:
            position = pygame.mouse.get_pos()
            coord = position[0] // self.elementSize, position[1] // self.elementSize
            # 如果鼠标在地图里
            if self.map_rect.collidepoint(position):
                # 若携带炮塔
                if self.mouseCarried[0] == 'turret':
                    screen.blit(self.mouseCarried[1].image, position)
                    # self.mouseCarried[1].coord = coord
                    # self.mouseCarried[1].position = position
                    # self.mouseCarried[1].rect.left, self.mouseCarried[1].rect.top = position
                else:  # 携带售卖图标
                    screen.blit(self.mouseCarried[1], position)

    '''拿炮塔'''

    def takeT(self):
        T = Turret.Turret()
        if self.money >= T.price:
            self.mouseCarried = ['turret', T]

    '''出售炮塔'''

    def takeX(self):
        XXX = pygame.image.load('imgs/X.png')
        self.mouseCarried = ['XXX', XXX]

    '''建造炮塔(500)'''

    def build_Turret(self, position):
        turret = self.mouseCarried[1]
        coord = position[0] // self.elementSize, position[1] // self.elementSize
        turret.position = position
        turret.coord = coord
        turret.rect.left, turret.rect.top = position

        # 鼠标在可建筑炮塔区域则可以建造
        # 如果此时的位置在地图字典键里对应的值为可以建造的地图元素块，则可以进行建造，反之不能
        if self.currentMap.get(turret.coord) in self.placeable.keys():
            self.money -= turret.price
            # 建造完毕要进行扣除总金币以及清空鼠标携带
            self.builtTurretGroup.add(turret)
            self.mouseCarried = []

    '''出售炮塔(半价)'''

    def sell_Turret(self, position):
        coord = position[0] // self.elementSize, position[1] // self.elementSize
        for turret in self.builtTurretGroup:
            if coord == turret.coord:
                self.builtTurretGroup.remove(turret)
                self.money += int(turret.price * 0.5)
                del turret
                break

    '''画已经建造好的炮塔'''

    def draw_BuiltTurret(self, screen):
        for turret in self.builtTurretGroup:
            screen.blit(turret.image, turret.rect)

    '''画敌人'''

    def draw_Enemies(self, screen):
        for enemy in self.EnemiesGroup:
            if enemy.life_value <= 0:
                self.money += enemy.reward
                self.score += enemy.score
                self.EnemiesGroup.remove(enemy)
                del enemy
                continue
            # 更新敌人位置
            # 判断敌人是否移动到下一个方块
            flag = enemy.move(self.elementSize)
            if flag:
                coord = self.find_next_path(enemy)  # 找下一个路径单元
                if coord:
                    # 走过路径进行添加
                    enemy.reached_path.append(enemy.coord)
                    # 先添加已走过道路，再更新新的道路方块
                    enemy.coord = coord
                    enemy.position = coord[0] * self.elementSize, coord[1] * self.elementSize  # find_next_path成功则位置更新
                    enemy.rect.left, enemy.rect.top = enemy.position
                else:  # 未找到下一个路径，说明敌人已经走到城堡位置，进行攻击
                    self.health -= enemy.damage
                    enemy.life_value = 0
                    # 攻击之后删除该敌人
                    self.EnemiesGroup.remove(enemy)
                    del enemy
                    continue
            # 更新敌人血条
            greenLen = max(0, enemy.life_value / enemy.max_life_value) * self.elementSize
            if greenLen > 0:
                pygame.draw.line(screen, green, (enemy.position), (enemy.position[0] + greenLen, enemy.position[1]), 3)
            if greenLen < self.elementSize:  # 画红色血条
                pygame.draw.line(screen, red, (enemy.position[0] + greenLen, enemy.position[1]),
                                 (enemy.position[0] + self.elementSize, enemy.position[1]), 3)
            screen.blit(enemy.image, enemy.position)

    '''找下一个路径单元'''

    def find_next_path(self, enemy):
        x, y = enemy.coord
        # 移动优先级: 下右左上
        neighbours = [(x, y + 1), (x + 1, y), (x - 1, y), (x, y - 1)]
        for neighbour in neighbours:  # 如果下一个方块是敌人通行道路方块，并且敌人没有走过说明找到了下一个所在方块
            if (neighbour in self.path_list) and (neighbour not in enemy.reached_path):
                return neighbour
        return None

    '''画出所有射出的炮弹'''

    def draw_Arrows(self, screen):
        for arrow in self.arrowsGroup:
            screen.blit(arrow.image, arrow.position)


'''游戏结束界面'''


class END():
    def __init__(self, WIDTH=None, HEIGHT=None):
        self.width = WIDTH
        self.height = HEIGHT
        self.image = pygame.image.load('imgs/game over.png')
        self.rect = self.image.get_rect()
        self.rect.center = (self.width // 2, self.height // 2)

    '''更新窗口游戏结束'''

    def update(self, screen):
        clock = pygame.time.Clock()
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # 用户关闭了游戏窗口，退出游戏
                    pygame.quit()
                    sys.exit()
            screen.blit(self.image, self.rect)
            pygame.display.flip()
            clock.tick(60)


'''主函数'''


def main():
    pygame.init()
    # 加载音乐
    pygame.mixer.init()
    pygame.mixer.music.load('music.ogg')
    pygame.mixer.music.play(-1, 0.0)
    pygame.mixer.music.set_volume(0.25)
    # 设置窗口以及游戏名称
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("守卫要塞")

    # 开始游戏
    game_start = GAMING(WIDTH, HEIGHT)
    game_start.start(screen)
    # 游戏结束
    game_end = END(WIDTH, HEIGHT)
    game_end.update(screen)
    pygame.display.flip()


'''run'''
if __name__ == '__main__':
    main()
